package com.hfad.mynotes.db

import androidx.room.Entity

@Entity
data class Note {
    val id: Int
    val title: String

}